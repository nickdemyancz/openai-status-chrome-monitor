# OpenAI Status Monitor (MVP)

A minimal Chrome extension (Manifest V3) showing OpenAI's publicly reported service status using a color-coded independent triangular emblem.

## Install (unpacked)

1. Open `chrome://extensions` in Google Chrome.
2. Enable **Developer mode**.
3. Choose **Load unpacked** and select the `openai-status-monitor` folder.
4. (Optional) Pin the extension to the toolbar via the puzzle-piece Extensions menu.
5. Click the logo to view selected services. Click the settings icon to select services and polling interval.

## Status colors

- Green: all systems operational (`indicator: none`).
- Yellow: partial degradation (`minor`) or maintenance.
- Red: major / critical OpenAI incidents.
- Gray: data not obtained or indicator unknown.

The toolbar dot represents the **overall status published by OpenAI**, not an aggregate of the user's selected components.

## Polling

- Intervals: 5, 30, 60 minutes; default 5 minutes.
- Manual mode (0): no scheduled status checks; click **Refresh** in the popup.
- The last successful check is shown in the popup. On fetch failure, the logo becomes gray; any previously retrieved component statuses are explicitly marked stale.
- Chrome's alarm scheduler is best effort and does not wake a sleeping device.

## Data sources and privacy

Direct requests to `https://status.openai.com/api/v2/status.json` and `https://status.openai.com/api/v2/components.json`. No API key, tracking, analytics, backend, or account access. No notification feature. Preferences are stored in `chrome.storage.local`.

The settings screen loads the component catalog dynamically and displays groups based on the current category boundaries of the public OpenAI status page (because the public API does not include group names). Services are identified by their unique IDs, including both separate `Login` components.

## Files

- `background.js`: status polling, caching, dynamic toolbar icon.
- `shared.js`: status labels/colors, display grouping, defaults.
- `popup.html`, `popup.js`: compact toolbar popup.
- `options.html`, `options.js`: settings.
- `styles.css`: shared styling and light/dark themes.
- `icons/`: colored triangular status icon PNGs (green/yellow/red/gray, 16/32/48/128 px).

Status is the published aggregate reported by OpenAI, not an independent uptime measurement for an individual account.

## Original visual identity (v0.1.3)

The extension uses an independently designed three-segment triangular emblem.
The permanent identity icon in Chrome's extension manager is green/yellow/red; the live toolbar icon switches between uniform green, yellow, red, and gray versions of **the same silhouette**.

- Green `#22C55E`: operational.
- Yellow `#EAB308`: partial issues / maintenance.
- Red `#EF4444`: major / critical issues.
- Gray `#9CA3AF`: data unavailable.

The SVG source artwork is included in `icons/brand.svg`, and the PNG variants are provided in the resolutions required by the extension manifest.
This is an unofficial, independent project. OpenAI and ChatGPT are trademarks of their respective owner; the custom icon is not the ChatGPT or OpenAI logo.
