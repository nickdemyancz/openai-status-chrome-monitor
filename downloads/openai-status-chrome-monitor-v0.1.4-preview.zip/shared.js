/* Shared display data. Component IDs, not names, identify services. */
(() => {
  const DEFAULT_SELECTED_IDS = [
    '01JMXBNJXGV1T5GT2M9XA83XNG', // ChatGPT / Conversations
    '01JMXBNJXG1S2D9V65P1ZZTD94', // ChatGPT / Login
    '01JMXBNJXGKKP51D4DEJ2HZJ8Q', // ChatGPT / Search
    '01JVCV8YSWZFRSM1G5CVP253SK'  // Codex / Codex Web
  ];

  // The public components API supplies stable IDs but not the website's
  // group headings. Display them by position, using ID boundaries.
  const GROUP_BOUNDARIES = new Map([
    ['01JMXBRMFE6N2NNT7DG6XZQ6PW', 'APIs'],
    ['01JMXBNJXGV1T5GT2M9XA83XNG', 'ChatGPT'],
    ['01JVCV8YSWZFRSM1G5CVP253SK', 'Codex'],
    ['01KKAD7C71MCCH3FTREMJH4AAS', 'FedRAMP'],
    ['01KTQBYVARFJ5KMCSECM06VKCF', 'Ads Platform']
  ]);
  const OTHER_GROUP = 'otherServices';

  const COLORS = {
    green: '#22c55e', yellow: '#eab308', red: '#ef4444', gray: '#9ca3af'
  };

  function overallMeta(indicator) {
    switch (indicator) {
      case 'none': return { color: 'green', key: 'overallOperational' };
      case 'minor': return { color: 'yellow', key: 'overallMinor' };
      case 'major':
      case 'critical': return { color: 'red', key: 'overallMajor' };
      case 'maintenance': return { color: 'yellow', key: 'overallMaintenance' };
      default: return { color: 'gray', key: 'statusUnknown' };
    }
  }

  function componentMeta(status) {
    switch (status) {
      case 'operational': return { color: 'green', key: 'componentOperational' };
      case 'degraded_performance': return { color: 'yellow', key: 'componentDegraded' };
      case 'partial_outage': return { color: 'yellow', key: 'componentPartial' };
      case 'under_maintenance': return { color: 'yellow', key: 'overallMaintenance' };
      case 'major_outage': return { color: 'red', key: 'overallMajor' };
      default: return { color: 'gray', key: 'statusUnknown' };
    }
  }

  function groupComponents(components) {
    const ordered = [...components].sort((a, b) =>
      (Number(a.position) || 0) - (Number(b.position) || 0)
    );
    const groups = [];
    let activeGroup = OTHER_GROUP;
    for (const component of ordered) {
      if (GROUP_BOUNDARIES.has(component.id)) {
        activeGroup = GROUP_BOUNDARIES.get(component.id);
      }
      if (!groups.length || groups[groups.length - 1].name !== activeGroup) {
        groups.push({ name: activeGroup, components: [] });
      }
      groups[groups.length - 1].components.push(component);
    }
    return groups;
  }

  function formatDate(dateString, locale = 'en', t = (key) => key) {
    if (!dateString) return t('dateNever');
    const date = new Date(dateString);
    if (Number.isNaN(date.getTime())) return t('dateUnknown');
    return new Intl.DateTimeFormat(locale, {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    }).format(date);
  }

  globalThis.OpenAIStatus = {
    DEFAULT_SELECTED_IDS, COLORS, OTHER_GROUP, overallMeta,
    componentMeta, groupComponents, formatDate
  };
})();
