/* UI translations are bundled in _locales/<code>/messages.json.
 * Chrome's built-in i18n API localizes the manifest; this small loader enables
 * a user-selected language for extension pages and the dynamic toolbar title.
 */
(() => {
  'use strict';
  const DEFAULT_LOCALE = 'en';
  const SUPPORTED_LOCALES = Object.freeze(['en', 'ru', 'cs']);
  const cache = new Map();

  function normalizePreference(preference) {
    return SUPPORTED_LOCALES.includes(preference) ? preference : 'auto';
  }

  function detectBrowserLocale() {
    let value = '';
    try { value = chrome.i18n.getUILanguage(); } catch (_) { /* tests */ }
    if (!value && typeof navigator !== 'undefined') value = navigator.language;
    const code = String(value || '').toLowerCase().replace('_', '-').split('-')[0];
    return SUPPORTED_LOCALES.includes(code) ? code : DEFAULT_LOCALE;
  }

  function resolveLocale(preference) {
    const normalized = normalizePreference(preference);
    return normalized === 'auto' ? detectBrowserLocale() : normalized;
  }

  function getCatalog(code) {
    if (!cache.has(code)) {
      const url = chrome.runtime.getURL(`_locales/${code}/messages.json`);
      cache.set(code, fetch(url).then(async (response) => {
        if (!response.ok) throw new Error(`Translation not found: ${code}`);
        return response.json();
      }).catch((error) => {
        cache.delete(code);
        throw error;
      }));
    }
    return cache.get(code);
  }

  async function createTranslator(preference) {
    const locale = resolveLocale(preference);
    const english = await getCatalog(DEFAULT_LOCALE);
    const translated = locale === DEFAULT_LOCALE ? english : await getCatalog(locale);
    return {
      locale,
      preference: normalizePreference(preference),
      t(key, substitutions = {}) {
        const template = translated[key]?.message ?? english[key]?.message ?? key;
        return template.replace(/\{([a-zA-Z][a-zA-Z0-9]*)\}/g, (match, placeholder) =>
          Object.prototype.hasOwnProperty.call(substitutions, placeholder)
            ? String(substitutions[placeholder]) : match);
      }
    };
  }

  function translatePage(translator, root = document) {
    root.documentElement.lang = translator.locale;
    for (const element of root.querySelectorAll('[data-i18n]')) {
      element.textContent = translator.t(element.dataset.i18n);
    }
    for (const element of root.querySelectorAll('[data-i18n-title]')) {
      element.title = translator.t(element.dataset.i18nTitle);
    }
    for (const element of root.querySelectorAll('[data-i18n-aria-label]')) {
      element.setAttribute('aria-label', translator.t(element.dataset.i18nAriaLabel));
    }
    for (const element of root.querySelectorAll('[data-i18n-placeholder]')) {
      element.setAttribute('placeholder', translator.t(element.dataset.i18nPlaceholder));
    }
  }

  globalThis.OpenAIStatusI18n = Object.freeze({
    SUPPORTED_LOCALES, DEFAULT_LOCALE, normalizePreference,
    detectBrowserLocale, resolveLocale, createTranslator, translatePage
  });
})();
