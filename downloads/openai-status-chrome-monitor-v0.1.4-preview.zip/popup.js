const { componentMeta, overallMeta, groupComponents, formatDate, DEFAULT_SELECTED_IDS } = OpenAIStatus;
const servicesEl = document.getElementById('services');
const overviewDot = document.getElementById('overall-dot');
const overviewText = document.getElementById('overall-text');
const checkedAt = document.getElementById('checked-at');
const warning = document.getElementById('warning');
const countEl = document.getElementById('selection-count');
const refreshButton = document.getElementById('refresh');
let renderGeneration = 0;

function dot(color) {
  const span = document.createElement('span');
  span.className = `status-dot ${color}`;
  span.setAttribute('aria-hidden', 'true');
  return span;
}

function createGroup(title, components, isStale, t) {
  const group = document.createElement('section');
  group.className = 'service-group';
  const heading = document.createElement('h2');
  heading.className = 'group-heading';
  heading.textContent = title;
  group.append(heading);

  for (const component of components) {
    const meta = componentMeta(component.status);
    const row = document.createElement('div');
    row.className = 'service-row';
    if (isStale) row.classList.add('stale');
    const name = document.createElement('span');
    name.className = 'service-name';
    name.textContent = component.name; // official service names are not translated
    const right = document.createElement('span');
    right.className = 'service-right';
    const status = document.createElement('span');
    status.className = 'service-status';
    status.textContent = t(meta.key);
    right.append(status, dot(meta.color));
    row.append(name, right);
    group.append(row);
  }
  return group;
}

function addPlaceholder(message) {
  const node = document.createElement('div');
  node.className = 'empty-state';
  node.textContent = message;
  servicesEl.append(node);
}

async function render() {
  const generation = ++renderGeneration;
  const values = await chrome.storage.local.get([
    'statusSnapshot', 'selectedIds', 'intervalMinutes', 'languagePreference'
  ]);
  const translator = await OpenAIStatusI18n.createTranslator(values.languagePreference);
  if (generation !== renderGeneration) return; // discard an obsolete async render
  const { t, locale } = translator;
  OpenAIStatusI18n.translatePage(translator);

  const snapshot = values.statusSnapshot;
  const selected = new Set(Array.isArray(values.selectedIds)
    ? values.selectedIds : DEFAULT_SELECTED_IDS);
  const intervalMinutes = values.intervalMinutes ?? 5;
  const hasSnapshot = snapshot && Array.isArray(snapshot.components);
  const hasError = Boolean(snapshot && snapshot.failed);
  const overall = !hasSnapshot || hasError
    ? { color: 'gray', key: hasError ? 'fetchFailed' : 'noData' }
    : overallMeta(snapshot.overallIndicator);

  overviewDot.className = `status-dot large ${overall.color}`;
  overviewText.textContent = t(overall.key);
  checkedAt.textContent = hasSnapshot && snapshot.lastSuccessAt
    ? t('updatedAt', { date: formatDate(snapshot.lastSuccessAt, locale, t) })
    : t('notLoadedYet');

  warning.hidden = true;
  if (hasError) {
    warning.textContent = hasSnapshot && snapshot.lastSuccessAt
      ? t('cachedDataNotice', { date: formatDate(snapshot.lastSuccessAt, locale, t) })
      : t('fetchFailedTryAgain');
    warning.hidden = false;
  } else if (!hasSnapshot && intervalMinutes === 0) {
    warning.textContent = t('manualModeNotice');
    warning.hidden = false;
  }

  servicesEl.replaceChildren();
  countEl.textContent = String(selected.size);
  if (selected.size === 0) {
    addPlaceholder(t('noSelectedServices'));
    return;
  }
  if (!hasSnapshot) {
    addPlaceholder(t('servicesLoadLater'));
    return;
  }

  let shownCount = 0;
  for (const group of groupComponents(snapshot.components)) {
    const matching = group.components.filter((item) => selected.has(item.id));
    if (!matching.length) continue;
    const heading = group.name === OpenAIStatus.OTHER_GROUP ? t('otherServices') : group.name;
    servicesEl.append(createGroup(heading, matching, hasError, t));
    shownCount += matching.length;
  }
  if (!shownCount) {
    addPlaceholder(t('selectedServicesMissing'));
  } else if (shownCount !== selected.size) {
    const note = document.createElement('p');
    note.className = 'tiny-note';
    note.textContent = t('servicesNotFoundCount', { count: selected.size - shownCount });
    servicesEl.append(note);
  }
}

document.getElementById('settings').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});
refreshButton.addEventListener('click', async () => {
  refreshButton.disabled = true;
  refreshButton.classList.add('refreshing');
  try {
    await chrome.runtime.sendMessage({ type: 'REFRESH' });
  } catch (error) {
    const { languagePreference } = await chrome.storage.local.get('languagePreference');
    const translator = await OpenAIStatusI18n.createTranslator(languagePreference);
    warning.hidden = false;
    warning.textContent = translator.t('refreshFailed');
  } finally {
    refreshButton.disabled = false;
    refreshButton.classList.remove('refreshing');
    await render();
  }
});
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' &&
      (changes.statusSnapshot || changes.selectedIds || changes.intervalMinutes || changes.languagePreference)) {
    void render();
  }
});
void render();
