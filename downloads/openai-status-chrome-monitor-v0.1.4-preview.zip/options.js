const { DEFAULT_SELECTED_IDS, groupComponents } = OpenAIStatus;
const groupContainer = document.getElementById('component-groups');
const catalogStatus = document.getElementById('catalog-status');
const selectedCount = document.getElementById('selected-count');
const savedMessage = document.getElementById('saved-message');
const intervalEl = document.getElementById('interval');
const languageEl = document.getElementById('language');
const saveButton = document.getElementById('save');
let selected = new Set(DEFAULT_SELECTED_IDS);
let catalog = [];
let catalogMessageKey = 'catalogLoading';
let noticeKey = '';
let translator = null;
let languagePreference = 'auto';
let translateGeneration = 0;

function t(key, values) {
  return translator ? translator.t(key, values) : key;
}

function setSelectedCount() {
  selectedCount.textContent = String(selected.size);
}

function clearNotice() {
  noticeKey = '';
  savedMessage.textContent = '';
}

function renderCatalog() {
  groupContainer.replaceChildren();
  if (!catalog.length) {
    catalogStatus.textContent = t(catalogMessageKey);
    catalogStatus.hidden = false;
    setSelectedCount();
    return;
  }
  catalogStatus.hidden = catalogMessageKey !== 'catalogCached';
  if (!catalogStatus.hidden) catalogStatus.textContent = t(catalogMessageKey);

  for (const group of groupComponents(catalog)) {
    const section = document.createElement('section');
    section.className = 'catalog-group';
    const title = document.createElement('h3');
    title.textContent = group.name === OpenAIStatus.OTHER_GROUP
      ? t('otherServices') : group.name;
    section.append(title);
    const grid = document.createElement('div');
    grid.className = 'checkbox-grid';

    for (const component of group.components) {
      const label = document.createElement('label');
      label.className = 'component-choice';
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.name = 'component';
      checkbox.value = component.id;
      checkbox.checked = selected.has(component.id);
      checkbox.addEventListener('change', () => {
        if (checkbox.checked) selected.add(component.id);
        else selected.delete(component.id);
        setSelectedCount();
        clearNotice();
      });
      const text = document.createElement('span');
      text.textContent = component.name;
      label.append(checkbox, text);
      grid.append(label);
    }
    section.append(grid);
    groupContainer.append(section);
  }
  setSelectedCount();
}

async function applyLanguage(preference) {
  const generation = ++translateGeneration;
  const next = await OpenAIStatusI18n.createTranslator(preference);
  if (generation !== translateGeneration) return;
  translator = next;
  languagePreference = OpenAIStatusI18n.normalizePreference(preference);
  OpenAIStatusI18n.translatePage(translator);
  document.title = t('optionsTitle');
  languageEl.value = languagePreference;
  renderCatalog();
  if (noticeKey) savedMessage.textContent = t(noticeKey);
}

async function fetchCatalog() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch('https://status.openai.com/api/v2/components.json', {
      cache: 'no-store', signal: controller.signal
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (!Array.isArray(data.components) || data.components.length === 0) {
      throw new Error('Empty component catalog');
    }
    const components = data.components.filter((c) =>
      c && typeof c.id === 'string' && typeof c.name === 'string'
    ).map((c) => ({
      id: c.id, name: c.name, status: c.status, position: c.position
    }));
    catalog = components;
    catalogMessageKey = '';
    await chrome.storage.local.set({ componentCatalog: components });
  } catch (error) {
    catalogMessageKey = catalog.length ? 'catalogCached' : 'catalogUnavailable';
  } finally {
    clearTimeout(timer);
    renderCatalog();
  }
}

async function init() {
  const values = await chrome.storage.local.get([
    'intervalMinutes', 'selectedIds', 'componentCatalog', 'languagePreference'
  ]);
  selected = new Set(Array.isArray(values.selectedIds)
    ? values.selectedIds : DEFAULT_SELECTED_IDS);
  intervalEl.value = String([0, 5, 30, 60].includes(values.intervalMinutes)
    ? values.intervalMinutes : 5);
  catalog = Array.isArray(values.componentCatalog) ? values.componentCatalog : [];
  catalogMessageKey = catalog.length ? '' : 'catalogLoading';
  await applyLanguage(values.languagePreference);
  await fetchCatalog();
}

document.getElementById('select-all').addEventListener('click', () => {
  for (const component of catalog) selected.add(component.id);
  renderCatalog();
  clearNotice();
});
document.getElementById('clear-all').addEventListener('click', () => {
  selected.clear();
  renderCatalog();
  clearNotice();
});
document.getElementById('settings-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  saveButton.disabled = true;
  clearNotice();
  try {
    await chrome.storage.local.set({
      intervalMinutes: Number(intervalEl.value),
      selectedIds: [...selected]
    });
    noticeKey = 'settingsSaved';
  } catch (error) {
    noticeKey = 'settingsSaveFailed';
  } finally {
    saveButton.disabled = false;
    savedMessage.textContent = t(noticeKey);
  }
});
languageEl.addEventListener('change', async () => {
  const next = languageEl.value;
  const previous = languagePreference;
  if (next === previous) return;
  try {
    // Language is a separate preference: switching applies and persists at once.
    await applyLanguage(next);
    await chrome.storage.local.set({ languagePreference: next });
  } catch (error) {
    await applyLanguage(previous);
    noticeKey = 'languageSaveFailed';
    savedMessage.textContent = t(noticeKey);
  }
});
intervalEl.addEventListener('change', clearNotice);
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.languagePreference &&
      changes.languagePreference.newValue !== languagePreference) {
    void applyLanguage(changes.languagePreference.newValue);
  }
});
void init();
